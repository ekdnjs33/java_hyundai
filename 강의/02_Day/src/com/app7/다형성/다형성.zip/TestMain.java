package com.app7.다형성;

public class TestMain {

	public static void main(String[] args) {
		/*
		 *   1) 객체지향프로그래밍(OOP) 3대 특징
		 *      - 상속(inheritance)
		 *      - 다형성(polymorphism)
		 *      - 은닉화(캡슐화, encapsulation)
		 * 
		 * 
		 *   2) 다형성
		 *     - 상속전제
		 *     - 개념: 하나의 변수가 서로 다른 데이터타입을 참조하는 능력 의미.
		 *     
		 *        문법:
		 *                       큰타입     = 작은타입;
		 *              부모클래스타입    변수  = new 자식클래스();
		 *     - 단 하나의 변수로 여러 데이터타입을 참조할 수 있다.         
		 */

	}

}
